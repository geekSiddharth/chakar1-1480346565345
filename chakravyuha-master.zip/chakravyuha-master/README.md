# chakravyuha.in

A online cryptic hunt portal created for Chakravyuha organized during Esya'16, the annual techinical fest of IIIT Delhi.
